package kr.ac.kumoh.s20151155.travelapp;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class ListViewAdapter extends BaseAdapter {

    private ArrayList<ListViewItem> listViewItemList = new ArrayList<ListViewItem>();

    //ListViewAdapter 생성자
    public ListViewAdapter(){

    }

    @Override
    public int getCount() {
        return listViewItemList.size();
    }

    @Override
    public Object getItem(int position) {
        return listViewItemList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final int pos = position;
        final Context context = parent.getContext();

        if(convertView==null){
            LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.listview_item, parent, false);
        }

        ImageView imageView = (ImageView)convertView.findViewById(R.id.imageView);
        TextView nameTextView = (TextView)convertView.findViewById(R.id.name);
        TextView fightTextView = (TextView)convertView.findViewById(R.id.fight_cost);
        TextView freightTextView = (TextView)convertView.findViewById(R.id.freight_cost);
        TextView specialTextView = (TextView)convertView.findViewById(R.id.special_cost);
        TextView chargeTextView = (TextView)convertView.findViewById(R.id.charge_cost);
        ListViewItem listViewItem = listViewItemList.get(position);

        imageView.setImageDrawable(listViewItem.getIcon());
       // imageView.setImageBitmap(listViewItem.getImage());
        nameTextView.setText(listViewItem.getCompanyName());
        fightTextView.setText("기내용 "+listViewItem.getFightCost());
        freightTextView.setText("화물용 "+listViewItem.getFreightCost());
        specialTextView.setText("특대용 "+listViewItem.getSpecialCost());
        chargeTextView.setText(""+listViewItem.getChargeCost());

        return convertView;
    }

    public void addItem(Drawable icon, String name, int fight, int freight, int special, int charge){
        ListViewItem item = new ListViewItem();

        item.setIcon(icon);
        //item.setImage(image);
        item.setName(name);
        item.setFightCost(fight);
        item.setFreightCost(freight);
        item.setSpecialCost(special);
        item.setChargeCost(charge);

        listViewItemList.add(item);
    }
}

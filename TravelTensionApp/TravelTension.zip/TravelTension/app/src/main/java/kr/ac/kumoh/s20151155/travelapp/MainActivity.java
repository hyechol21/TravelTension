package kr.ac.kumoh.s20151155.travelapp;

import android.content.Intent;
import android.location.Address;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.DialogFragment;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import static java.security.AccessController.getContext;

//맵 오류

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    String resultID;

    Button login_button;

    //주소
    List<Address> list = null;

    //선택위치
    double startLat=0;
    double startLon=0;
    double endLat=0;
    double endLon=0;

    //현재 날짜 텍스트
    long now = System.currentTimeMillis();
    Date date = new Date(now);
    SimpleDateFormat now_year = new SimpleDateFormat("yyyy");
    SimpleDateFormat now_month = new SimpleDateFormat("M");
    SimpleDateFormat now_day = new SimpleDateFormat("d");

    String formatMonth = now_month.format(date);
    String formatYear = now_year.format(date);
    String formatDay = now_day.format(date);

    TextView yearTx;
    TextView monthTx;
    TextView dayTx;

    EditText countEdit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        countEdit = (EditText)findViewById(R.id.count);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


        //네비게이션 헤더
        View nav_header_view = navigationView.getHeaderView(0);

        login_button = (Button) nav_header_view.findViewById(R.id.loginBtn);
        login_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                //수정필요 (데이터 넘기는것)
                startActivityForResult(intent, 100);
            }
        });

        //현재 날짜 (자동 기입)
        yearTx = (TextView)findViewById(R.id.date_year);
        monthTx = (TextView)findViewById(R.id.date_month);
        dayTx = (TextView)findViewById(R.id.date_day);

        yearTx.setText(formatYear);
        monthTx.setText(formatMonth);
        dayTx.setText(formatDay);

        //짐 종류 콤보박스
        final Spinner spinner = (Spinner) findViewById(R.id.spinner_bag);
        /*final ArrayAdapter adapter = ArrayAdapter.createFromResource(this, R.array.baggage,
                android.R.layout.simple_spinner_dropdown_item);
*/
        /*final ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.baggage,
                R.layout.spinner_item);*/

        String[] str = getResources().getStringArray(R.array.baggage);
        //final ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
        //        R.layout.spinner_item, R.id.spinner_text, str);
        ArrayAdapter adapter = new ArrayAdapter(this, R.layout.spinner_item,
                str);

        adapter.setDropDownViewResource(R.layout.spinner_dropdown);

        spinner.setAdapter(adapter);




        //시작위치 버튼
        Button startBtn = (Button)findViewById(R.id.departure);
        startBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MapActivity.class);
                startActivityForResult(intent,200);
            }
        });

        //도착위치 버튼
        Button EndBtn = (Button)findViewById(R.id.destination);
        EndBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MapActivity.class);
                startActivityForResult(intent,300);
            }
        });

        //검색 하기 버튼
        Button searchBtn = (Button) findViewById(R.id.search);
        searchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

               // Toast.makeText(MainActivity.this,area_start, Toast.LENGTH_SHORT).show();
                String baggage = spinner.getSelectedItem().toString();


                String getCount = countEdit.getText().toString();

                int count;
                if(getCount.getBytes().length <= 0)
                    count = 0;
                else
                    count = Integer.parseInt(countEdit.getText().toString());

                Intent intent = new Intent(MainActivity.this, ListActivity.class);
                intent.putExtra("id", resultID);
                intent.putExtra("startLat", startLat);
                intent.putExtra("startLon", startLon);
                intent.putExtra("endLat", endLat);
                intent.putExtra("endLon", endLon);
                intent.putExtra("year", formatYear);
                intent.putExtra("month", formatMonth);
                intent.putExtra("day", formatDay);
                intent.putExtra("count",count);
                intent.putExtra("baggageType",baggage);
                startActivity(intent);
            }
        });

    }

    //로그인 intent 보낸 결과
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode != RESULT_OK) {

        }

        if (requestCode == 100) {
            resultID = data.getStringExtra("current_id");
            login_button.setText(resultID);
        }
        else if(requestCode == 200){
            startLat = data.getDoubleExtra("location_lat",0);
            startLon = data.getDoubleExtra("location_lon",0);
            Toast.makeText(this, startLat+", "+startLon, Toast.LENGTH_SHORT).show();


            //행정구역 이름 구하기
            /*Geocoder gCoder = new Geocoder(getApplicationContext(), Locale.getDefault());
            List<Address> addr = null;
            try {
                addr = gCoder.getFromLocation(resultLat, resultLon,1);
            } catch (IOException e) {
                e.printStackTrace();
            }
            Address address = addr.get(0);

            if(address.getLocality()!=null)
                area_start = address.getLocality();
            else
                area_start = address.getAdminArea();

            Toast.makeText(this, area_start, Toast.LENGTH_SHORT).show();*/

        }else if(requestCode == 300){
            endLat= data.getDoubleExtra("location_lat",0);
            endLon = data.getDoubleExtra("location_lon",0);
            Toast.makeText(this, endLat+", "+endLon, Toast.LENGTH_SHORT).show();

           /* Geocoder gCoder = new Geocoder(getApplicationContext(), Locale.getDefault());
            List<Address> addr =null;
            try {
                addr = gCoder.getFromLocation(resultLat, resultLon,1);
            } catch (IOException e) {
                e.printStackTrace();
            }
            Address address = addr.get(0);

            if(address.getLocality()!=null)
                area_end = address.getLocality();
            else
                area_end = address.getAdminArea();
            Toast.makeText(this, area_end, Toast.LENGTH_SHORT).show();*/
        }
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_search) { //검색버튼 클릭
            return true;
        }
        if(id == R.id.action_home){ //홈버튼클릭
            return true;
        }
        if(id == R.id.action_back) {//뒤로가기버튼 클릭
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_detail) {
            Intent intent = new Intent(MainActivity.this, DetailActivity.class);
            startActivity(intent);
        } else if (id == R.id.nav_review) {

        } else if (id == R.id.nav_messanger) {

        } else if (id == R.id.nav_inqury) {
            Intent intent = new Intent(MainActivity.this, noticeActivity.class);
            startActivityForResult(intent,500);
        } else if (id == R.id.nav_advertise) {
            Intent intent = new Intent(MainActivity.this, BusinessActivity.class);
            startActivityForResult(intent,400);
        } else if (id == R.id.nav_TaC){
            Intent intent = new Intent(MainActivity.this, tacActivity.class);
            startActivityForResult(intent,600);
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    //날짜 달력
    public void showDatePickerDialog(View v) {
        DialogFragment newFragment = new DatePickerFragment();
        newFragment.show(getSupportFragmentManager(), "datePicker");
    }
}



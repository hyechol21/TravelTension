package kr.ac.kumoh.s20151155.travelapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class noticeActivity extends AppCompatActivity {

    static final String[] List_MENU = {"첫번째 공지사항입니다","두번째 공지사항입니다","세번째 공지사항입니다"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notice);

        ArrayAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1,List_MENU);
        ListView listView = (ListView) findViewById(R.id.nlist);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                int pposition = position +1;
                switch (pposition){
                    case 1:
                        Intent mIntent = new Intent(noticeActivity.this,tacActivity.class);
                        startActivityForResult(mIntent,700);
                        break;
                    case 2:
                        Intent nmIntent = new Intent(noticeActivity.this,MainActivity.class);
                        startActivityForResult(nmIntent,750);
                        break;
                    case 3:
                        Intent nnIntent = new Intent(noticeActivity.this,LoginActivity.class);
                        startActivityForResult(nnIntent,800);
                        break;
            }
        }

        });


    }

}

package kr.ac.kumoh.s20151155.travelapp;

import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

public class ListViewItem{

    private Drawable iconDrawable;

    private Bitmap image;
    private String companyName;
    private int fightCost;
    private int freightCost;
    private int specialCost;
    private int chargeCost;
    //private String freightCost;

    public void setIcon(Drawable icon){
        iconDrawable = icon;
    }
    /*public void setImage(Bitmap img){
        image = img;
    }*/
    public void setName(String name){
        companyName = name;
    }
    public void setFightCost(int fight){
        fightCost = fight;
    }
    public void setFreightCost(int freight){
        freightCost = freight;
    }
    public void setSpecialCost(int special){
        specialCost = special;
    }
    public void setChargeCost(int charge){
        chargeCost = charge;
    }

    public Drawable getIcon(){
        return this.iconDrawable;
    }
   /* public Bitmap getImage(){
        return this.image;
    }*/
    public String getCompanyName(){
        return this.companyName;
    }
    public int getFightCost(){
        return this.fightCost;
    }
    public int getFreightCost(){
        return this.freightCost;
    }
    public int getSpecialCost(){
        return this.specialCost;
    }
    public int getChargeCost(){
        return this.chargeCost;
    }


}
